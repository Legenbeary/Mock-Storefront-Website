
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sign Up</title>
	<!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">
	
    
	<link rel="stylesheet" href="signup.css"/>
	
    
  </head>

  

<body>

	<body class="text-center">
  
	<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-black">
    <a class="navbar-brand" href="#">FreeAircraftAuction.com</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index2.html">Home <span class="sr-only">(current)</span></a>
        </li>
        
		<li class="nav-item active">
          <a class="nav-link" href="signIn.php">Sign In <span class="sr-only">(current)</span></a>
        </li>
		
		<li class="nav-item active">
          <a class="nav-link" href="signup.php">Sign Up <span class="sr-only">(current)</span></a>
        </li>
      </ul>
		<form class="form-inline mt-2 mt-md-0">
			<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>	  
    </div>
  </nav>
</header>

<body>
	<form action="" method= "post">
	<img  src="img2/logo3.jpg" alt="" ><br /><br /><br />
		<div class="container">
			<h1>Register</h1>
			<p>Please fill in this form to create an account.</p>
			<hr>
			
			<label for="uName"><b>Username</b></label>
			<input type="text" placeholder="Enter Username" name="regUserName" id="regUserName" required>
			
			<!--<label for="lName"><b>Last Name</b></label>
			<input type="text" placeholder="Enter Last Name" name="lName" id="lName" required>-->

			<!--<label for="email"><b>Email</b></label>
			<input type="text" placeholder="Enter Email" name="email" id="email" required>-->

			<label for="psw"><b>Password</b></label>
			<input type="password" placeholder="Enter Password" name="regPsw" id="psw" required>

			<label for="pswRepeat"><b>Repeat Password</b></label>
			<input type="password" placeholder="Repeat Password" name="pswRepeat" id="pswRepeat" required>
			<hr>
			
			
			
			

			<p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
			<button type="submit" name="registerbtn" class="registerbtn">Register</button>
		</div>

		<div class="container signin">
			<p>Already have an account? <a href="signIn.php">Sign in</a>.</p>
		</div>
	</form>
	
<?php
//if submit button pressed keep going 
if(isset($_POST["registerbtn"]))
{
$hostname='localhost';
$username='jachop7328';
$password='password';

$passOne = $_POST['regPsw'];
$passTwo = $_POST['pswRepeat'];

	//check for correct password entry
	if($passOne !== $passTwo)
	{
		echo "<p><font color=red>passwords do not match</p>";
	}
	else
	{
		try {
		$dbh = new PDO("mysql:host=$hostname;dbname=logindb",$username,$password);
		// query that inserts data into table
		$sql = "INSERT INTO regusers (username, password)
				VALUES ('".$_POST["regUserName"]."','".$_POST["regPsw"]."')";
	
		//check for successful entry
		if ($dbh->query($sql)) {
		echo "<p><font color=white>You are now registered!</p>";
		}
		else{
		echo "<p><font color=red>Registration was unsuccessful</p>";
		}
	
		$dbh = null;
		}
		catch(PDOException $e)
		{
		echo $e->getMessage();
		}
	}
}
?>
	
</body>
<footer class="container">
    <p class="float-right"><a href="#">Back to top</a></p>
    <p>&copy; 2020 FreeAircraftAuction, Inc. &middot; <a href="img/privacy.jpg">Privacy</a> &middot; <a href="#">Terms</a></p>
  </footer>
</html>
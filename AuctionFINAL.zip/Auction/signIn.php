<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sign In</title>
	<!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">
	
    
	<link rel="stylesheet" href="signin2.css"/>
    
  </head>

  <body class="text-center">
  
	<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-black">
    <a class="navbar-brand" href="#">FreeAircraftAuction.com</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index2.html">Home <span class="sr-only">(current)</span></a>
        </li>
        
		<li class="nav-item active">
          <a class="nav-link" href="signIn.php">Sign In <span class="sr-only">(current)</span></a>
        </li>
		
		<li class="nav-item active">
          <a class="nav-link" href="signup.php">Sign Up <span class="sr-only">(current)</span></a>
        </li>
      </ul>
		<form class="form-inline mt-2 mt-md-0">
			<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>	  
    </div>
  </nav>
</header>

    <body>
	<form action="auclogin.php" name="signin" method="post">
	<img  src="img2/logo3.jpg" alt="" ><br /><br /><br />
		<div class="container">
			<h1>Sign In</h1>
			
			<hr>
			<label for="username" class="sr-only">Email address</label>
				<input type="text" id="inputUsername" name="inputUsername" class="form-control" placeholder="Username" required autofocus>
			<label for="inputPassword" class="sr-only">Password</label>
				<input type="password" id="inputPassword" name="inputPassword" class="form-control" placeholder="Password" required><br />
				<hr>
				
			<div class="checkbox mb-3">
				<label><input type="checkbox" value="remember-me"> Remember me</label><br />
			
        </div>
			
			
			
			
			

			<p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
			<button class="btn1 btn-lg btn-primary btn-block" name="loginBtn" type="submit">Sign in</button>
			<p class="mt-5 mb-3 text-muted">&copy; FreeAircraftAuction.com 2020</p>
		</div>
		
  </body>
  <footer class="container">
    <p class="float-right"><a href="#">Back to top</a></p>
    <p>&copy; 2020 FreeAircraftAuction, Inc. &middot; <a href="img/privacy.jpg">Privacy</a> &middot; <a href="#">Terms</a></p>
  </footer>
</html>
<?php 
	//create session
	session_start();  

	//connect to db
    $dbhost = "localhost"; 
	$dbuser = "jachop7328"; 
	$dbpass = "password"; 
	$dbname = "logindb"; 
	$dbconn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname); 
	//value returned is a handle
	
	//user name and password from the form
	$userName = filter_input(INPUT_POST,"inputUsername");
	$passWord = filter_input(INPUT_POST,"inputPassword");

	//connection test
    if (mysqli_connect_errno())
	{ 
		die("Database connection failed" . mysqli_connect_error() . " (" . mysqli_connect_errno() . ")" ); //die means exit or break
	//display error version using error and number
	}
    else 
	{
		//query database connection
		$query = "SELECT login_id, username, password FROM regusers		
				 WHERE username = '$userName' AND password = '$passWord'";
		$result = mysqli_query($dbconn, $query);
		//$row = mysqli_fetch_row($result);
	}
	
	//if user not found, redirect
		if(mysqli_num_rows($result) == 0)
		{
			header("Location: signup.php");
		}
		//test for query error
			if (!$result)
			{ 
				die("Database query failed");
			}
		else
		{
			$_SESSION["userlogin"] = "user";	
		}
	
	
	
//close the database connection
	mysqli_close($dbconn);	

?>

<!doctype html> 
<html lang="en">
	<head>
		<meta charset="utf-8" />
	<head>
		<title>Logged In</title>
	</head>
	<body>
		<h1>
			You are now logged in
		</h1>
		<h2>
			<p>
				<a class="btn btn-secondary" href="index2logged.html" role="button">Return to Home &raquo;</a>
			</p>
		</h2>
	</body>
</html> 
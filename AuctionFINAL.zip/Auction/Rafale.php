<?php 
//create sassion
session_start();  

//if not signed in redirect 
		if (empty($_SESSION['userlogin'])) 
		{
				header ("Location: signIn.php");
		}
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <!--
      CIS224 Project
      Author: Schoblocher, Hopkins
	  Auction Page
      Date:   
   -->
   <meta charset="utf-8" />
   <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
   <title>Aircraft Auction</title>
   
   <link rel="stylesheet" href="index2.css"/>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
</head>
<body id="black">
<body>

<!--Nav-->

<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <a class="navbar-brand" href="#">FreeAircraftAuction.com</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index2logged.html">Home</a>
        </li>
        
      </ul>
		<form class="form-inline mt-2 mt-md-0">
			<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>	  
    </div>
  </nav>
</header>



<!-- Page Content -->
<div class="container2">

  <!-- Portfolio Item Heading -->
  <h1 class="my-4">Dassault Rafale
    <small>French Multi-Role Fighter</small>
  </h1>

  <!-- Portfolio Item Row -->
  <div class="row">

    <div class="col-md-8">
      <img class="img-fluid" src="img2/Rafale.jpg" alt="">
    </div>

    <div class="col-md-4">
      <h3 class="my-3">Aircraft Description</h3>
      <p>The Dassault Rafale (French pronunciation: ​[ʁafal], literally meaning "gust of wind", and "burst of fire" in a more military sense) is a French twin-engine, canard delta wing, multirole fighter aircraft designed and built by Dassault Aviation.</p>
      <h3 class="my-3">Aircraft Details</h3>
      <ul>
        <li>Multi-role attack and fighter aircraft.</li>
        <li>Max. Speed: Mach 1.8 (1381.08 MPH)</li>
        <li>Length: 15.30 meters.</li>
        <li>Height: 5.30 meters.</li>
      </ul>
    </div>
	<div class="btn-group2">
        <p><a class="btn btn-secondary" href="f35.php" role="button">Bid &raquo;</a></p>
    </div>
	
	<div class="btn-group2">
        <p><a class="btn btn-secondary" href="f35.php" role="button">Buy Now! &raquo;</a></p>
    </div>

  </div>
  <!-- /.row -->

  <!-- Related Projects Row -->
  <h3 class="my-4">Other Aircraft</h3>

  <div class="row">

    <div class="col-md-3 col-sm-6 mb-4">
      <a href="f35.php">
            <img class="img-fluid" src="img2/f353.jpg" alt="">
          </a>
    </div>

    <div class="col-md-3 col-sm-6 mb-4">
      <a href="su57.php">
            <img class="img-fluid" src="img2/su57.jpg" alt="">
          </a>
    </div>

    <div class="col-md-3 col-sm-6 mb-4">
      <a href="B2Bomber.php">
            <img class="img-fluid" src="img2/b2.jpg" alt="">
          </a>
    </div>

    <div class="col-md-3 col-sm-6 mb-4">
      <a href="hornetProduct.php">
            <img class="img-fluid" src="img2/f18-hornet--1.jpg" alt="">
          </a>

  </div>
  <!-- /.row -->

</div>
<!-- /.container -->
  
  
  
  
  
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<?php
 include 'footer.php';
?>	
 </body>
 </html>
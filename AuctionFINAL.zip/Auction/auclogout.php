<?php 
//if there is a file get it; if not create it
//sessions use cookies
session_start();  //default name for session cookies is PHPSESSID

//is session login set
//if not set redirect to login page
if (!(isset($_SESSION['userlogin']) && $_SESSION['userlogin'] != '')) 
{
	header ("Location: signIn.php");
}

$_SESSION = array();   // clears the $_SESSION variable data from memory
session_destroy(); //session set for the user will be destroyed
?>

<!DOCTYPE html>
<html>
	<head>
		<title>
			Logout Session
		</title>
	</head>
	<body>
		<h1>
			You have been logged out
		</h1>
		<h2>
			<p>
				<a class="btn btn-secondary" href="index2.html" role="button">Return to Home &raquo;</a>
			</p>
		</h2>	
		<br /><br />
	</body>
</html>
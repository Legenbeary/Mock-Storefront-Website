<?php 
//create sassion
session_start();  

//if not signed in redirect 
		if (empty($_SESSION['userlogin'])) 
		{
				header ("Location: signIn.php");
		}
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <!--
      CIS224 Project
      Author: Schoblocher, Hopkins
	  Auction Page
      Date:   
   -->
   <meta charset="utf-8" />
   <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
   <title>Aircraft Auction</title>
   
   <link rel="stylesheet" href="index2.css"/>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
</head>
<body id="black">
<body>

<!--Nav-->

<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <a class="navbar-brand" href="#">FreeAircraftAuction.com</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index2logged.html">Home</a>
        </li>
        
      </ul>
		<form class="form-inline mt-2 mt-md-0">
			<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>	  
    </div>
  </nav>
</header>



<!-- Page Content -->
<div class="container2">

  <!-- Portfolio Item Heading -->
  <h1 class="my-4">SU-57 Felon
    <small>Fifth generation stealth fighter</small>
  </h1>

  <!-- Portfolio Item Row -->
  <div class="row">

    <div class="col-md-8">
      <img class="img-fluid" src="img2/su572.jpg" alt="">
    </div>

    <div class="col-md-4">
      <h3 class="my-3">Aircraft Description</h3>
      <p>The Sukhoi Su-57 (Russian: Сухой Су-57; unconfirmed NATO reporting name: Felon) is a stealth, single-seat, twin-engine multirole fifth-generation jet fighter being developed since 2002 for air superiority and attack operations. The fighter is designed to have supercruise, supermaneuverability, stealth, and advanced avionics to overcome the prior generation fighter aircraft as well as ground and naval defences. The Su-57 is intended to succeed the MiG-29 and Su-27 in the Russian Air Force.</p>
      <h3 class="my-3">Aircraft Details</h3>
      <ul>
        <li>Fifth generation, stealth fighter</li>
        <li>Power Plant: Unknown</li>
        <li>Length: 22 meter (72 foot).</li>
        <li>Height: 5.45 meter (17.9 foot).</li>
      </ul>
    </div>
	
	<div class="btn-group2">
        <p><a class="btn btn-secondary" href="f35.php" role="button">Bid &raquo;</a></p>
    </div>
	<div class="btn-group2">
        <p><a class="btn btn-secondary" href="f35.php" role="button">Buy Now! &raquo;</a></p>
    </div>

  </div>
  <!-- /.row -->

  <!-- Related Projects Row -->
  <h3 class="my-4">Other Aircraft</h3>

  <div class="row">

    <div class="col-md-3 col-sm-6 mb-4">
      <a href="hornetProduct.php">
            <img class="img-fluid" src="img2/f18-hornet--1.jpg" alt="">
          </a>
    </div>

    <div class="col-md-3 col-sm-6 mb-4">
      <a href="f35.php">
            <img class="img-fluid" src="img2/f35.jpg" alt="">
          </a>
    </div>

    <div class="col-md-3 col-sm-6 mb-4">
      <a href="B2Bomber.php">
            <img class="img-fluid" src="img2/b2.jpg" alt="">
          </a>
    </div>

    <div class="col-md-3 col-sm-6 mb-4">
      <a href="Rafale.php">
            <img class="img-fluid" src="img2/Dassault_Rafale_Fighter.jpg" alt="">
          </a>

  </div>
  <!-- /.row -->

</div>
<!-- /.container -->
  
  
  
  
  
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<?php
 include 'footer.php';
?>	
 </body>
 </html>